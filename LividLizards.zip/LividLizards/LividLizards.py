import tkinter as tk
from tkinter import PhotoImage
import time
import random

# Global Variables
wall_hp = random.randint(200, 250)
curr_Lizard = None

# Create Lizard Class
class Lizard:
    def __init__(self, name, size, speed, damage):
        self.name = name
        self.size = size
        self.speed = speed
        self.damage = damage

    def Deal_damage(self):
        power = self.damage * self.size * self.speed // 2
        crit = random.randint(1, 5)
        if crit == 3:
            power = int(power * 1.5)
            global wall_hp
            wall_hp = wall_hp - power
            time.sleep(1.0)
            wall_health.config(text=("HP:", wall_hp))
            wall_health.update()
            if wall_hp <= 0:
                wall_destroyed()
        else:
            wall_hp = wall_hp - power
            time.sleep(1.0)
            wall_health.config(text=("HP:", wall_hp))
            wall_health.update()
            if wall_hp <= 0:
                wall_destroyed()

Lizards_list = [
    Lizard("Draco", 3, 2, 20),
    Lizard("Spike", 1, 3, 15),
    Lizard("Titan", 5, 1, 25),
    Lizard("Venom", 3, 2, 18),
    Lizard("Lightning", 3, 2, 22),
    Lizard("Swift", 1, 3, 17),
    Lizard("Blaze", 5, 1, 28),
    Lizard("Frost", 3, 2, 21),
    Lizard("Cyclone", 1, 3, 16),
    Lizard("Goliath", 5, 1, 30)
]
curr_Lizard = Lizards_list[0]

# Functions
def wall_destroyed():
    wall_health.destroy()
    wall.destroy()

    victory = tk.Label(frame, text="VICTORY!", fg="#D4AF37", bg="#4CBB17", font="bold 50")
    victory.place(x=150, y=100, width=500, height=50)

def select_lizard(event):
    if listbox.curselection():  
        index = listbox.curselection()[0]
        global curr_Lizard
        curr_Lizard = Lizards_list[index]
        list_window.destroy()
        lizardL.config(text=("L:", curr_Lizard.name))
        lizardL.update()

def show_Lizards_list():
    global list_window
    list_window = tk.Toplevel(frame)
    list_window.title("Lizard Selection")
    list_window.iconbitmap("Logo.ico")
    
    # Calculate the position of the scroller window relative to the main window
    x_offset = frame.winfo_x() + 650
    y_offset = frame.winfo_y() + 620
    list_window.geometry(f"+{x_offset}+{y_offset}")

    scrollbar = tk.Scrollbar(list_window)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    global listbox
    listbox = tk.Listbox(list_window, yscrollcommand=scrollbar.set, selectbackground="yellow")
    for lizard in Lizards_list:
        listbox.insert(tk.END, f"{lizard.name} [{lizard.damage}, {lizard.speed}, {lizard.size}]")
    listbox.pack(side=tk.LEFT, fill=tk.BOTH)

    scrollbar.config(command=listbox.yview)

    listbox.bind("<Button-1>", select_lizard)

# Create main window
frame = tk.Tk()
frame.title("Livid Lizards")
frame.geometry("800x800")
frame.iconbitmap("Logo.ico")

bg_im = PhotoImage(file="im_backdrop.png").zoom(16, 16)
back = tk.Label(frame, image=bg_im)
back.place(x=0, y=0, height=800, width=800)

cannon_im = PhotoImage(file="im_cannon.png").zoom(2, 2)
cannon = tk.Label(frame, image=cannon_im, bg="#4CBB17")
cannon.place(x=225, y=500, height=350, width=350)

wall_im = PhotoImage(file="im_wall.png")
wall = tk.Button(frame, image=wall_im, bg="#4CBB17", command=curr_Lizard.Deal_damage)
wall.place(x=250, y=50, height=200, width=300)

wall_health = tk.Label(frame, text=("HP:", wall_hp), bg="#4CBB17", fg="red", font="bold 25")
wall_health.place(x=600, y=50, height=25, width=150)

lizardL = tk.Label(frame, text=("L:", curr_Lizard.name), font="bold 20", fg="#1A2421", bg="#4CBB17")
lizardL.place(x=60, y=750, width=150, height=20)

listB = tk.Button(frame, text="Lizards", fg="black", bg="#29AB87", command=show_Lizards_list, font="bold 15")
listB.place(x=680, y=750, width=100, height=40)

frame.mainloop()
